package com.cg.ma.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.ma.bean.BookingDetails;
import com.cg.ma.bean.Bus;

import com.cg.ma.exception.BookingException;
import com.cg.ma.service.BusService;
import com.cg.ma.service.BusServiceImpl;

public class BusClient 
{
	static Scanner sc=null;
	static BusService bs=null; 

	public static void main(String[] args) {
		bs=new BusServiceImpl();
		sc=new Scanner(System.in);

		while(true)
		{
			System.out.println("What Do U Want To Do ?");
			System.out.println(" 1: Book Ticket \t 2: Exit \t ");

			int choice=sc.nextInt();
			switch(choice)
			{

			case 1: fetchBusDetails();
			break;

			default: System.exit(0);   
			}

		}

	}

	public static void fetchBusDetails()
	{
		int custId=0;
		int busId=0;
		String busType = null;
		String fromStop = null;
		String toStop = null;
		int availableSeats=0;
		int fare=0;
		String Doj=null;
		int noOfSeats = 0;

		//Bus b = new Bus();


		try
		{
			ArrayList<Bus> busList=bs.getBusDetail();

			for(Bus b:busList)
			{
				System.out.println(b.getBusId());
				System.out.println(b.getBusType());
				System.out.println(b.getFromStop());
				System.out.println(b.getToStop());
				System.out.println(b.getAvailableSeats());
				System.out.println(b.getFare());
				System.out.println(b.getDoj());
			}

			{
				System.out.println("Enter Customer Id: ");
				custId=sc.nextInt();
				if(bs.validateCId(custId)){


					{		
						System.out.println("Please Enter BusId :");
						busId=sc.nextInt();
						if(bs.validateBId(busId)){

							{

								System.out.println("Enter number of seats ");
								noOfSeats=sc.nextInt();
								if(bs.validateseat(noOfSeats))
								{


									BookingDetails bd =new BookingDetails();				
									bd.setCustId(custId);
									bd.setBusId(busId);
									bd.setNoOfSeats(noOfSeats);


									int dataAdded=bs.bookTicket(bd);

									if(dataAdded==1)
									{
										System.out.println("Mobile Data Added");
									}
									else
									{

										System.out.println("May Be Some Exception While Addition");
									}
								}
							}
						}
					}
				}
			}
		}





		catch (BookingException e) 
		{
			e.printStackTrace();
			System.out.println("Some Exception While Fetching Data");
		}
	}
}


