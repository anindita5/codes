package com.cg.ma.exception;

public class BookingException extends Exception {
	public BookingException(String msg){
		super(msg);
	}

}
