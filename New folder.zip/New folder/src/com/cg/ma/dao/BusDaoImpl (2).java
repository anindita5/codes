package com.cg.ma.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;














import com.cg.ma.util.DBUtil;
import com.cg.ma.bean.BookingDetails;
import com.cg.ma.bean.Bus;
import com.cg.ma.exception.BookingException;



public class BusDaoImpl implements BusDao{
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	//@Override
	public ArrayList<Bus> getBusDetail() throws BookingException
	{
		ArrayList<Bus> empList=new ArrayList<Bus>();
		String selectQry="Select * FROM busdetails";
		Bus ee=null;
		
		try 
		{
			
			con=DBUtil.getCon();
			st=con.createStatement();
			rs=st.executeQuery(selectQry);
			while(rs.next())
			{
					     ee=new Bus(rs.getInt("busId"),
			    		 rs.getString("busType"),
			    		 rs.getString("fromstop"),
			    		 rs.getString("tostop"),
			    		 rs.getString("fare"),
			    		 rs.getInt("availableseats"),
			    		 rs.getString("dateofjourney")
			    		 );
			     
			     empList.add(ee);
			}
		//	 empLogger.log(Level.INFO, "Employee Fetched"+emp);
		} 
		catch (Exception e) 
		{
			throw new BookingException(e.getMessage());
		} 
//		finally
//		{
//			try
//			{
//				rs.close();
//				st.close();
//				con.close();
//			} 
//
//			catch (SQLException e) 
//			{
//			//	empLogger.error("This is exception"+e.getMessage());
//				throw new BookingException(e.getMessage());
//			}
//			
//		}
		
		return empList;
	}
	
@Override
public int bookTicket(BookingDetails b) throws BookingException 
{
	{
        String insertQry="Insert Into bookingdetails(bookingid,custid,busid,noofseats) Values(?,?,?,?)";
        int dataAdded=0;
           try 
        {
            con=DBUtil.getCon();
            pst=con.prepareStatement(insertQry);
            pst.setInt(1, generateBookingId());
            pst.setLong(2, b.getCustId());
            pst.setLong(3, b.getBusId());
            pst.setLong(4, b.getNoOfSeats());

            
            dataAdded=pst.executeUpdate();
            
            
        } 
        catch (Exception e) 
        {
            throw new BookingException(e.getMessage());
        } 
        finally
        {
            try 
            {
                pst.close();
                con.close();
            } 
            catch (SQLException e) 
            {
                throw new BookingException(e.getMessage());
            }
        }
        
        return dataAdded;
	}
}

@Override
public int generateBookingId() throws BookingException {
	String qry="Select emp_seq.NextVal From Dual";

    int generatedVal;
    try 
    {
    
        con=DBUtil.getCon();
        st=con.createStatement();
        rs=st.executeQuery(qry);
        rs.next();
        generatedVal=rs.getInt(1);

    } 

    catch (Exception e) 
    {

        throw new BookingException(e.getMessage());
    
    }
    
    finally
    {
        try
        {
            rs.close();
            st.close();
            con.close();
        } 

        catch (SQLException e) 
        {
            throw new BookingException(e.getMessage());
        }
        
    }
    
    return generatedVal;

}

}


