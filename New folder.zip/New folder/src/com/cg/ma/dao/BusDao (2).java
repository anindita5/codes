package com.cg.ma.dao;
import java.util.ArrayList;

import com.cg.ma.bean.*;
import com.cg.ma.exception.BookingException;

public interface BusDao 
{
	public ArrayList<Bus> getBusDetail() throws BookingException;
	int bookTicket(BookingDetails b) throws BookingException;
	public int generateBookingId() throws BookingException;

}
