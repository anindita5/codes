package com.cg.ma.bean;

public class Bus 
{
	private int busId;
	private String busType;
	private String fromStop;
	private String toStop;
	private int availableSeats;
	private String fare;
	private String doj;
	
	
	
	public Bus() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bus(int busId, String busType, String fromStop, String toStop, String fare,
			int availableSeats , String doj) {
		super();
		this.busId = busId;
		this.busType = busType;
		this.fromStop = fromStop;
		this.toStop = toStop;
		this.availableSeats = availableSeats;
		this.fare = fare;
		this.doj = doj;
	}
	public int getBusId() {
		return busId;
	}
	public void setBusId(int busId) {
		this.busId = busId;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getFromStop() {
		return fromStop;
	}
	public void setFromStop(String fromStop) {
		this.fromStop = fromStop;
	}
	public String getToStop() {
		return toStop;
	}
	public void setToStop(String toStop) {
		this.toStop = toStop;
	}
	public int getAvailableSeats() {
		return availableSeats;
	}
	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}
	public String getFare() {
		return fare;
	}
	public void setFare(String fare) {
		this.fare = fare;
	}
	public String getDoj() {
		return doj;
	}
	public void setDoj(String doj) {
		this.doj = doj;
	}
	
	

}
