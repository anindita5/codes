package com.cg.ma.service;

import java.util.ArrayList;

import com.cg.ma.bean.BookingDetails;
import com.cg.ma.bean.Bus;
import com.cg.ma.dao.BusDao;
import com.cg.ma.dao.BusDaoImpl;
import com.cg.ma.exception.BookingException;

public class BusServiceImpl implements BusService {
	
	BusDao busDao = new BusDaoImpl();

	@Override
	public ArrayList<Bus> getBusDetail() throws BookingException {
		
		return busDao.getBusDetail();
	}

	@Override
	public int bookTicket(BookingDetails b) throws BookingException {
		return busDao.bookTicket(b);
		}

	@Override
	public boolean validateCId(int custId) throws BookingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateBId(int busId) throws BookingException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateseat(int noOfSeats) throws BookingException {
		// TODO Auto-generated method stub
		return false;
	}

}
