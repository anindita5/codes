package com.cg.ma.service;

import java.util.ArrayList;

import com.cg.ma.bean.BookingDetails;
import com.cg.ma.bean.Bus;
import com.cg.ma.exception.BookingException;


public interface BusService {
	public ArrayList<Bus> getBusDetail() throws BookingException;
	int bookTicket(BookingDetails b) throws BookingException;
	public boolean validateCId(int custId) throws BookingException;
	public boolean validateBId(int busId) throws BookingException;
	public boolean validateseat(int noOfSeats) throws BookingException;

}
